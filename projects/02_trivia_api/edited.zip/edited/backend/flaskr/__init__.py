import os
from flask import Flask, request, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import random

from models import setup_db, Question, Category

QUESTIONS_PER_PAGE = 10

def paginate_questions(request, selection):
  page = request.args.get('page', 1, type=int)
  start = (page - 1) * QUESTIONS_PER_PAGE
  end = start + QUESTIONS_PER_PAGE

  questions = [question.format() for question in selection]
  current_question = questions[start:end]

  return current_question

def create_app(test_config=None):
  # create and configure the app
  app = Flask(__name__)
  setup_db(app)
  
  '''
  Sets up CORS. Allow '*' for origins. Delete the sample route after completing the TODOs
  '''
  CORS(app, resources={r"/questions/*": {"origins": "*"}, r"/categories/*": {"origins": "*"}})
  '''
  After_request decorator to set Access-Control-Allow
  '''
  @app.after_request
  def after_request(response):
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,true')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response
  '''
  Endpoint to handle GET requests 
  for all available categories.
  '''
  @app.route("/categories")

  def get_categories():
    try:
      selection = Category.query.order_by(Category.id).all()
      categories = [category.format()['type'] for category in selection]

      return jsonify({
        'success': True,
        'categories': categories
      })
    except:
      abort(404)

  '''
  Endpoint to handle GET requests for questions, 
  including pagination (every 10 questions). 
  This endpoint returns a list of questions, 
  number of total questions, current category, categories. 
  '''
  @app.route("/questions")
  def get_questions():
    try:
      selection = Question.query.order_by(Question.id).all()
      current_questions = paginate_questions(request, selection)

      selection_category = Category.query.order_by(Category.id).all()
      categories = [category.format()['type'] for category in selection_category]

      category_id = request.args.get('currentCategory', 1, type=int)
      current_category = [Category.query.filter(Category.id == category_id).first().format()['type']]

      return jsonify({
        'success': True,
        'questions': current_questions,
        'total_questions': len(Question.query.all()),
        'current_category': current_category,
        'categories': categories
      })
    except:
      abort(404)
  '''
  Endpoint to DELETE question using a question ID. 
  '''
  @app.route("/questions/<int:question_id>", methods=['DELETE'])
  def delete_questions(question_id):
    question = Question.query.filter(Question.id == question_id).one_or_none()

    if question is not None:
      question.delete()
    else:
      abort(422)

    return jsonify({
      'success': True,
      'deleted': question_id,
      'total_questions': len(Question.query.all())
    })

  '''
  Endpoint to POST a new question, 
  which will require the question and answer text, 
  category, and difficulty score. 
  Instead it can get questions based on a search term. 
  It should return any questions for whom the search term 
  is a substring of the question. 

  '''
  @app.route("/questions", methods=['POST'])

  def create_questions():

    body = request.get_json()

    new_question = body.get('question', None)
    new_answer = body.get('answer', None)
    new_category = body.get('category', None)
    new_difficulty = body.get('difficulty', None)
    search_term = body.get('searchTerm', None)

    if search_term != None:
      try:
        selection = Question.query.filter(Question.question.ilike('%' + search_term + '%')).all()
        question = paginate_questions(request, selection)

        return jsonify({
          'success': True,
          'questions': question
        })
      except:
        abort(422)
    else:
      try:
        question = Question(question=new_question, answer=new_answer, category=new_category, difficulty=new_difficulty)
        question.insert()

        return jsonify({
          'success': True,
          'created': question.id,
          'total_questions': len(Question.query.all())
          })
      except:
        abort(422)

  '''
  GET endpoint to get questions based on category. 
  '''
  @app.route("/categories/<int:category_id>")

  def get_current_category(category_id):
    try:
      current_category = [Category.query.filter(Category.id == category_id+1).first().format()]

      selections = Question.query.filter(Question.category == category_id+1).all()
      questions = paginate_questions(request, selections)

      return jsonify({
        'success': True,
        'questions': questions,
        'total_questions': len(Question.query.all()),
        'current_category': current_category
      })
    except:
      abort(404)


  '''
  POST endpoint to get questions to play the quiz. 
  This endpoint takes category and previous question parameters 
  and return a random questions within the given category, 
  if provided, and that is not one of the previous questions. 
  '''
  @app.route("/quizzes", methods=['POST'])
  def play_quizzes():
    body = request.get_json()
    previous_questions = body.get('previous_questions', None)
    quiz_category = body.get('quiz_category', None)

    try:
      if quiz_category == None:
        selection = [question.format() for question in Question.query.filter(~Question.id.in_(previous_questions)).all()]
      else:
        selection = [question.format() for question in Question.query.filter(Question.category == int(quiz_category['id']) + 1).filter(~Question.id.in_(previous_questions)).all()]

      current_question = random.choice(selection)
      previous_questions.append(current_question['id'])

      return jsonify({
        'success': True,
        'quizCategory': quiz_category,
        'previousQuestions': previous_questions,
        'question': current_question
      })
    except:
      abort(404)

  '''
  Error handlers for all expected errors 
  including 400, 404, 405 and 422. 
  '''
  @app.errorhandler(400)
  def not_modified(error):
    return jsonify({
      "success": False,
      "error": 400,
      "message": "bad request"
    }), 400

  @app.errorhandler(404)
  def not_found(error):
    return jsonify({
      "success": False,
      "error": 404,
      "message": "Not found"
    }), 404

  @app.errorhandler(405)
  def not_found(error):
    return jsonify({
      "success": False,
      "error": 405,
      "message": "method not allowed"
    }), 405

  @app.errorhandler(422)
  def not_modified(error):
    return jsonify({
      "success": False,
      "error": 422,
      "message": "unprocessable entity"
    }), 422


  return app

    